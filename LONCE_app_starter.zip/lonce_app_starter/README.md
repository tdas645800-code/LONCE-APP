# LONCE

All-in-one Android app starter: Food, Grocery, Shopping, Ride and Parcel.

## Build
Install Flutter, then run:
flutter pub get
flutter run

For an APK:
flutter build apk --release

For Google Play:
flutter build appbundle --release

This is an MVP UI starter. Firebase, payments, maps, real orders, rider system and admin backend are not connected yet.

import 'package:flutter/material.dart';

void main() => runApp(const LonceApp());

class LonceApp extends StatelessWidget {
  const LonceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'LONCE',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2457E6),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    });
  }
  @override
  Widget build(BuildContext context) => const Scaffold(
    body: Center(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.apps_rounded, size: 72, color: Color(0xFF2457E6)),
        SizedBox(height: 12),
        Text('LONCE', style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800)),
        SizedBox(height: 6),
        Text('Sab Kuch, Ek Hi App Mein'),
      ]),
    ),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final services = const [
    ['Food', Icons.restaurant_rounded],
    ['Grocery', Icons.shopping_basket_rounded],
    ['Shopping', Icons.shopping_bag_rounded],
    ['Ride', Icons.two_wheeler_rounded],
    ['Parcel', Icons.local_shipping_rounded],
    ['More', Icons.grid_view_rounded],
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LONCE', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.shopping_cart_outlined)),
        ],
      ),
      body: IndexedStack(index: tab, children: [
        _home(),
        const OrdersScreen(),
        const ProfileScreen(),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Orders'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
    children: [
      TextField(
        decoration: InputDecoration(
          hintText: 'Search food, grocery, rides...',
          prefixIcon: const Icon(Icons.search),
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 18),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: const Color(0xFFE8EEFF)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Everything you need', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          SizedBox(height: 6),
          Text('Food • Grocery • Shopping • Ride • Parcel'),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('Services', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      GridView.builder(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        itemCount: services.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .95),
        itemBuilder: (_, i) => InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => ServiceScreen(title: services[i][0] as String, icon: services[i][1] as IconData))),
          child: Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(services[i][1] as IconData, size: 34, color: const Color(0xFF2457E6)),
              const SizedBox(height: 8),
              Text(services[i][0] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ),
    ],
  );
}

class ServiceScreen extends StatelessWidget {
  final String title; final IconData icon;
  const ServiceScreen({super.key, required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 80, color: const Color(0xFF2457E6)),
      const SizedBox(height: 16),
      Text('$title coming soon', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const Text('This module will be connected in the next version.'),
    ])),
  );
}

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Text('No orders yet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)));
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [
    CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44)),
    SizedBox(height: 12),
    Center(child: Text('Guest User', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
    SizedBox(height: 24),
    ListTile(leading: Icon(Icons.location_on_outlined), title: Text('Saved Addresses'), trailing: Icon(Icons.chevron_right)),
    ListTile(leading: Icon(Icons.account_balance_wallet_outlined), title: Text('Wallet'), trailing: Icon(Icons.chevron_right)),
    ListTile(leading: Icon(Icons.help_outline), title: Text('Help & Support'), trailing: Icon(Icons.chevron_right)),
    ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings'), trailing: Icon(Icons.chevron_right)),
  ]);
}
